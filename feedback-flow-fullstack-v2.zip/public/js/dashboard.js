/**
 * HOD Analytics Dashboard & Modular UI Renderers
 */

let deptChart = null;

async function initHodDashboard() {
  try {
    const res = await fetch('/api/dashboard');
    const data = await res.json();

    // Render Summary KPI Metrics
    renderSummaryKPIs(data.summary);

    // Render Top 3 Strengths & Grievances
    if (data.topKeywords) {
      renderTopKeywords('topStrengthsContainer', data.topKeywords.topStrengths || [], 'strength');
      renderTopKeywords('topGrievancesContainer', data.topKeywords.topGrievances || [], 'grievance');
    }

    // Render Visualizations & Tables
    renderDepartmentChart(data.faculty || []);
    renderBenchmarkTable(data.faculty || []);
    renderFacultyCards(data.faculty || []);
  } catch (err) {
    console.error('Failed to load HOD Dashboard:', err);
  }
}

function renderSummaryKPIs(summary) {
  if (!summary) return;
  const hapEl = document.getElementById('kpiHappiness');
  const avgEl = document.getElementById('kpiAvgScore');
  const totEl = document.getElementById('kpiTotalReviews');

  if (hapEl) hapEl.innerText = `${summary.departmentHappinessIndex || 0}%`;
  if (avgEl) avgEl.innerText = (summary.averageSentimentScore > 0 ? '+' : '') + summary.averageSentimentScore;
  if (totEl) totEl.innerText = summary.totalReviews || 0;
}

function renderTopKeywords(containerId, items, type) {
  const container = document.getElementById(containerId);
  if (!container) return;
  container.innerHTML = '';

  if (items.length === 0) {
    container.innerHTML = '<p style="color:#94a3b8; font-size:0.9rem;">No keywords recorded yet.</p>';
    return;
  }

  items.forEach((item, index) => {
    const badge = document.createElement('div');
    badge.className = `keyword-badge ${type}`;
    badge.style.cssText = `
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 0.6rem 1rem;
      margin-bottom: 0.5rem;
      border-radius: 8px;
      font-weight: 600;
      background-color: ${type === 'strength' ? 'rgba(16, 185, 129, 0.15)' : 'rgba(239, 68, 68, 0.15)'};
      border-left: 4px solid ${type === 'strength' ? '#10b981' : '#ef4444'};
      color: ${type === 'strength' ? '#34d399' : '#fca5a5'};
    `;
    badge.innerHTML = `
      <span>#${index + 1} ${item.keyword}</span>
      <span style="font-size:0.8rem; background:rgba(255,255,255,0.1); padding:0.2rem 0.5rem; border-radius:12px;">${item.count} mentions</span>
    `;
    container.appendChild(badge);
  });
}

function renderDepartmentChart(facultyList) {
  const canvas = document.getElementById('chartDepartmentSentiment');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');

  let pos = 0, neu = 0, neg = 0;
  facultyList.forEach(f => {
    if (f.sentimentDistribution) {
      pos += f.sentimentDistribution.positive || 0;
      neu += f.sentimentDistribution.neutral || 0;
      neg += f.sentimentDistribution.negative || 0;
    }
  });

  if (deptChart) deptChart.destroy();

  deptChart = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: ['Positive Sentiment', 'Neutral', 'Negative Concerns'],
      datasets: [{
        data: [pos, neu, neg],
        backgroundColor: ['#10b981', '#f59e0b', '#ef4444'],
        borderWidth: 2,
        borderColor: '#1e293b'
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { labels: { color: '#cbd5e1' } }
      }
    }
  });
}

function renderBenchmarkTable(facultyList) {
  const tbody = document.getElementById('benchmarkTableBody');
  if (!tbody) return;
  tbody.innerHTML = '';

  facultyList.forEach(f => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><strong>${f.name}</strong><br><small style="color:#94a3b8">${f.course}</small></td>
      <td>${f.teachingClarity} ⭐</td>
      <td>${f.pacing} ⭐</td>
      <td>${f.doubtResolution} ⭐</td>
      <td><span class="badge ${f.overallSentiment >= 0.3 ? 'positive' : f.overallSentiment <= -0.1 ? 'negative' : 'neutral'}">${f.overallSentiment}</span></td>
    `;
    tbody.appendChild(tr);
  });
}

function renderFacultyCards(facultyList) {
  const grid = document.getElementById('facultyCardsGrid');
  if (!grid) return;
  grid.innerHTML = '';

  facultyList.forEach(f => {
    const card = document.createElement('div');
    card.className = 'card';
    card.innerHTML = `
      <h3>${f.name}</h3>
      <p style="color:#94a3b8; font-size:0.9rem; margin-bottom:0.8rem;">${f.course}</p>
      
      <div style="display:flex; gap:0.5rem; align-items:center; margin-bottom:1rem;">
        <span style="font-weight:700;">Overall Sentiment:</span>
        <span class="badge ${f.overallSentiment >= 0.3 ? 'positive' : f.overallSentiment <= -0.1 ? 'negative' : 'neutral'}">Score: ${f.overallSentiment} (${f.reviewCount} Reviews)</span>
      </div>

      <div style="background-color:#0f172a; padding:0.8rem; border-radius:6px; font-size:0.85rem; border-left:4px solid #38bdf8; margin-top:0.8rem;">
        <strong style="color:#38bdf8;">🎯 HOD Actionable Recommendation:</strong><br>
        <span style="color:#e2e8f0;">${f.actionRecommendation || 'Maintain active engagement and monitor feedback.'}</span>
      </div>
    `;
    grid.appendChild(card);
  });
}
