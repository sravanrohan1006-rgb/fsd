const http = require('http');
const path = require('path');
const fs = require('fs');
const url = require('url');

const { analyzeSentiment } = require('./lib/sentimentEngine');
const { anonymizeSubmission } = require('./lib/privacyShield');
const { getAllFaculty, getFacultyById, getAllFeedback, insertFeedback } = require('./lib/db');
const { sanitizeHtml } = require('./lib/validation');
const { rateLimiter } = require('./lib/rateLimiter');
const { extractTopKeywords } = require('./lib/keywordExtractor');

const PORT = process.env.PORT || 5500;
const HOST = '127.0.0.1';
const PUBLIC_DIR = path.join(__dirname, 'public');

const mimeTypes = {
  '.html': 'text/html',
  '.css': 'text/css',
  '.js': 'text/javascript',
  '.json': 'application/json',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.svg': 'image/svg+xml'
};

function serveStatic(req, res, filePath) {
  fs.stat(filePath, (err, stats) => {
    if (err || !stats.isFile()) {
      // Fallback to index.html for SPA routing
      const indexPath = path.join(PUBLIC_DIR, 'index.html');
      fs.readFile(indexPath, (indexErr, content) => {
        if (indexErr) {
          res.writeHead(404, { 'Content-Type': 'text/plain' });
          res.end('404 Not Found');
          return;
        }
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.end(content);
      });
      return;
    }

    const ext = path.extname(filePath).toLowerCase();
    const contentType = mimeTypes[ext] || 'application/octet-stream';

    fs.readFile(filePath, (readErr, content) => {
      if (readErr) {
        res.writeHead(500, { 'Content-Type': 'text/plain' });
        res.end('Internal Server Error');
        return;
      }
      res.writeHead(200, { 'Content-Type': contentType });
      res.end(content);
    });
  });
}

function parseJsonBody(req, callback) {
  let body = '';
  req.on('data', chunk => {
    body += chunk.toString();
    if (body.length > 1e6) req.destroy(); // Protect against flood
  });
  req.on('end', () => {
    try {
      const parsed = body ? JSON.parse(body) : {};
      callback(null, parsed);
    } catch (e) {
      callback(e, null);
    }
  });
}

const server = http.createServer((req, res) => {
  const parsedUrl = url.parse(req.url, true);
  const pathname = parsedUrl.pathname;

  // CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  // API 1: Health check
  if (req.method === 'GET' && pathname === '/api/health') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      status: 'OK',
      system: 'FeedbackFlow SentimentScope v2.0 (SQLite Powered)',
      timestamp: new Date().toISOString()
    }));
    return;
  }

  // API 2: Get faculty list & benchmarks
  if (req.method === 'GET' && pathname === '/api/faculty') {
    const faculty = getAllFaculty();
    const count = faculty.length || 1;

    const departmentAvg = {
      teachingClarity: parseFloat((faculty.reduce((acc, f) => acc + f.teachingClarity, 0) / count).toFixed(2)),
      pacing: parseFloat((faculty.reduce((acc, f) => acc + f.pacing, 0) / count).toFixed(2)),
      doubtResolution: parseFloat((faculty.reduce((acc, f) => acc + f.doubtResolution, 0) / count).toFixed(2)),
      overallSentiment: parseFloat((faculty.reduce((acc, f) => acc + f.overallSentiment, 0) / count).toFixed(2))
    };

    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      department: 'Department of Computer Science & Engineering',
      faculty,
      departmentAvg
    }));
    return;
  }

  // API 3: Get HOD Dashboard metrics (with Top 3 Keywords)
  if (req.method === 'GET' && pathname === '/api/dashboard') {
    const faculty = getAllFaculty();
    const allReviews = getAllFeedback();

    const totalReviews = allReviews.length;
    const count = faculty.length || 1;
    const avgSentiment = parseFloat(
      (faculty.reduce((sum, f) => sum + f.overallSentiment, 0) / count).toFixed(2)
    );

    const reviewTexts = allReviews.map(r => r.reviewText || r.text);
    const { topStrengths, topGrievances } = extractTopKeywords(reviewTexts, 3);

    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      department: 'Department of Computer Science & Engineering',
      summary: {
        totalFaculty: faculty.length,
        totalReviews,
        departmentHappinessIndex: Math.round(((avgSentiment + 1) / 2) * 100),
        averageSentimentScore: avgSentiment
      },
      topKeywords: {
        topStrengths,
        topGrievances
      },
      faculty,
      recentReviews: allReviews.slice(0, 10)
    }));
    return;
  }

  // API 4: Post Anonymous Feedback
  if (req.method === 'POST' && pathname === '/api/feedback') {
    // Apply Rate Limiter
    let isRateLimited = false;
    const dummyRes = {
      setHeader(k, v) { res.setHeader(k, v); },
      status(code) {
        isRateLimited = true;
        res.writeHead(code, { 'Content-Type': 'application/json' });
        return {
          json(data) { res.end(JSON.stringify(data)); }
        };
      }
    };

    rateLimiter(req, dummyRes, () => {
      parseJsonBody(req, (err, body) => {
        if (err) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: 'Malformed JSON payload' }));
          return;
        }

        const { facultyId, teachingClarity, pacing, doubtResolution, textReview } = body;
        const errors = [];

        if (!facultyId || typeof facultyId !== 'string' || facultyId.trim() === '') {
          errors.push('Faculty selection is required.');
        }

        const clarityNum = Number(teachingClarity);
        const pacingNum = Number(pacing);
        const doubtNum = Number(doubtResolution);

        if (isNaN(clarityNum) || clarityNum < 1 || clarityNum > 5) {
          errors.push('Teaching clarity rating must be a number between 1 and 5.');
        }
        if (isNaN(pacingNum) || pacingNum < 1 || pacingNum > 5) {
          errors.push('Lecture pacing rating must be a number between 1 and 5.');
        }
        if (isNaN(doubtNum) || doubtNum < 1 || doubtNum > 5) {
          errors.push('Doubt resolution rating must be a number between 1 and 5.');
        }

        if (!textReview || typeof textReview !== 'string' || textReview.trim().length < 5) {
          errors.push('Qualitative text review must be at least 5 characters long.');
        }

        if (errors.length > 0) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: 'Validation Error', details: errors }));
          return;
        }

        const clientIp = req.headers['x-forwarded-for'] || req.socket.remoteAddress;
        const sanitizedText = sanitizeHtml(textReview.trim());
        const anonymizedPayload = { sessionToken: body.sessionToken, textReview: sanitizedText, ...body };
        const { anonymizedSessionHash } = anonymizeSubmission(anonymizedPayload, clientIp);

        const facultyObj = getFacultyById(facultyId);
        if (!facultyObj) {
          res.writeHead(404, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: 'Faculty member not found' }));
          return;
        }

        const sentimentAnalysis = analyzeSentiment(sanitizedText);

        const newReview = {
          id: 'rev_' + Date.now(),
          facultyId: facultyObj.id,
          course: facultyObj.course,
          ratings: {
            clarity: clarityNum,
            pacing: pacingNum,
            doubt: doubtNum
          },
          text: sanitizedText,
          sentimentScore: sentimentAnalysis.score,
          polarity: sentimentAnalysis.polarity,
          anonymousToken: anonymizedSessionHash,
          timestamp: new Date().toISOString()
        };

        insertFeedback(newReview);
        const updatedFaculty = getFacultyById(facultyId);

        res.writeHead(201, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
          message: 'Anonymous feedback recorded successfully in database.',
          anonymizedToken: anonymizedSessionHash,
          sentimentResult: sentimentAnalysis,
          updatedFacultyScore: updatedFaculty ? updatedFaculty.overallSentiment : 0
        }));
      });
    });
    return;
  }

  // Serve static files
  let safePath = path.normalize(pathname).replace(/^(\.\.[\/\\])+/, '');
  if (safePath === '/' || safePath === '\\') safePath = '/index.html';
  const fullPath = path.join(PUBLIC_DIR, safePath);
  serveStatic(req, res, fullPath);
});

if (require.main === module) {
  server.listen(PORT, HOST, () => {
    console.log(`===================================================`);
    console.log(`🚀 FeedbackFlow Fullstack v2 Server active at http://${HOST}:${PORT}`);
    console.log(`===================================================`);
  });
}

module.exports = server;
