const test = require('node:test');
const assert = require('node:assert');
const { extractTopKeywords } = require('../lib/keywordExtractor');

test('KeywordExtractor - Ranks and extracts Top 3 strengths and grievances', () => {
  const sampleReviews = [
    'Clear explanations and clear concepts.',
    'Clear explanations with helpful doubt resolution.',
    'Great lectures, but lecture pacing was too fast.',
    'Fast lecture pacing and out of syllabus exam questions.'
  ];

  const { topStrengths, topGrievances } = extractTopKeywords(sampleReviews, 3);

  assert.ok(Array.isArray(topStrengths));
  assert.ok(topStrengths.length <= 3);
  assert.ok(Array.isArray(topGrievances));
  assert.ok(topGrievances.length <= 3);

  assert.strictEqual(topStrengths[0].keyword, 'Clear Explanations');
  assert.strictEqual(topGrievances[0].keyword, 'Fast Lecture Pacing');
});
