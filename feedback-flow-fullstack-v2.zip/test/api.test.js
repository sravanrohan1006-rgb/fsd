const test = require('node:test');
const assert = require('node:assert');
const server = require('../server');

let baseUrl;

test.before(async () => {
  await new Promise((resolve) => {
    server.listen(0, '127.0.0.1', () => {
      const port = server.address().port;
      baseUrl = 'http:' + '//127.0.0.1:' + port;
      resolve();
    });
  });
});

test.after(async () => {
  await new Promise((resolve) => {
    server.close(resolve);
  });
});

test('API GET /api/health returns 200 OK', async () => {
  const res = await fetch(baseUrl + '/api/health');
  const data = await res.json();
  assert.strictEqual(res.status, 200);
  assert.strictEqual(data.status, 'OK');
});

test('API GET /api/faculty returns faculty list and benchmarks', async () => {
  const res = await fetch(baseUrl + '/api/faculty');
  const data = await res.json();
  assert.strictEqual(res.status, 200);
  assert.ok(Array.isArray(data.faculty));
  assert.ok(data.departmentAvg);
});

test('API GET /api/dashboard returns HOD metrics and Top 3 keywords', async () => {
  const res = await fetch(baseUrl + '/api/dashboard');
  const data = await res.json();
  assert.strictEqual(res.status, 200);
  assert.ok(data.summary);
  assert.ok(data.topKeywords.topStrengths.length <= 3);
  assert.ok(data.topKeywords.topGrievances.length <= 3);
});

test('API POST /api/feedback submits valid feedback', async () => {
  const payload = {
    facultyId: 'fac_ds_01',
    teachingClarity: 5,
    pacing: 4,
    doubtResolution: 5,
    textReview: 'Excellent lectures with clear code demonstrations.',
    sessionToken: 'test_token_999'
  };

  const res = await fetch(baseUrl + '/api/feedback', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });

  const data = await res.json();
  assert.strictEqual(res.status, 201);
  assert.ok(data.anonymizedToken);
  assert.strictEqual(data.sentimentResult.polarity, 'Positive');
});
