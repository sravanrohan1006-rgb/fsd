const test = require('node:test');
const assert = require('node:assert');
const { validateFeedbackInput, sanitizeHtml } = require('../lib/validation');

test('Validation - HTML tag sanitization prevents XSS injections', () => {
  const maliciousInput = '<script>alert("xss")</script><b>Good class</b>';
  const sanitized = sanitizeHtml(maliciousInput);
  assert.ok(!sanitized.includes('<script>'));
  assert.ok(sanitized.includes('&lt;script&gt;'));
});

test('Validation - Rejects invalid feedback input payloads', () => {
  const req = {
    body: {
      facultyId: '',
      teachingClarity: 10, // Invalid rating > 5
      pacing: 3,
      doubtResolution: 4,
      textReview: 'bad' // Too short (< 5 chars)
    }
  };

  const res = {
    statusCode: 0,
    jsonPayload: null,
    status(code) {
      this.statusCode = code;
      return this;
    },
    json(data) {
      this.jsonPayload = data;
      return this;
    }
  };

  validateFeedbackInput(req, res, () => {});
  assert.strictEqual(res.statusCode, 400);
  assert.strictEqual(res.jsonPayload.error, 'Validation Error');
  assert.ok(res.jsonPayload.details.length >= 2);
});
