const test = require('node:test');
const assert = require('node:assert');
const { anonymizeSubmission } = require('../lib/privacyShield');

test('PrivacyShield - Computes 16-character SHA-256 session token hash', () => {
  const reqBody = { sessionToken: 'student_12345', textReview: 'Great class!' };
  const result = anonymizeSubmission(reqBody, '192.168.1.1');
  assert.strictEqual(typeof result.anonymizedSessionHash, 'string');
  assert.strictEqual(result.anonymizedSessionHash.length, 16);
});

test('PrivacyShield - Redacts PII email addresses and student IDs from review text', () => {
  const reqBody = { textReview: 'Contact john.doe@univ.edu or student ID 202630015 for questions.' };
  const result = anonymizeSubmission(reqBody, '127.0.0.1');
  assert.ok(result.sanitizedText.includes('[REDACTED_EMAIL]'));
  assert.ok(result.sanitizedText.includes('[REDACTED_ID]'));
  assert.ok(!result.sanitizedText.includes('john.doe@univ.edu'));
  assert.ok(!result.sanitizedText.includes('202630015'));
});
