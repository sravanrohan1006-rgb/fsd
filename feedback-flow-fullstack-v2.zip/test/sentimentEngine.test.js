const test = require('node:test');
const assert = require('node:assert');
const { analyzeSentiment } = require('../lib/sentimentEngine');

test('SentimentEngine - Positive feedback evaluation', () => {
  const result = analyzeSentiment('Great theoretical explanations and excellent doubt resolution.');
  assert.strictEqual(result.polarity, 'Positive');
  assert.ok(result.score > 0);
});

test('SentimentEngine - Negative feedback evaluation', () => {
  const result = analyzeSentiment('Slides move too fast and exam pattern was confusing.');
  assert.strictEqual(result.polarity, 'Negative');
  assert.ok(result.score < 0);
});

test('SentimentEngine - Academic collegiate idioms scoring', () => {
  const resultPositive = analyzeSentiment('Prof is a chill professor');
  assert.strictEqual(resultPositive.polarity, 'Positive');

  const resultNegative = analyzeSentiment('Questions were out of syllabus');
  assert.strictEqual(resultNegative.polarity, 'Negative');
});

test('SentimentEngine - Handles empty or invalid input gracefully', () => {
  const resultEmpty = analyzeSentiment('');
  assert.strictEqual(resultEmpty.score, 0);
  assert.strictEqual(resultEmpty.polarity, 'Neutral');

  const resultNull = analyzeSentiment(null);
  assert.strictEqual(resultNull.score, 0);
  assert.strictEqual(resultNull.polarity, 'Neutral');
});
